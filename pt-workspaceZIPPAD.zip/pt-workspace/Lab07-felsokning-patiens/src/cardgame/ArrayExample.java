package cardgame;

import pair.Pair;

public class ArrayExample {

	public static void main(String[] args) {
		Pair[] pairs = new Pair[7];
		pairs[0] = new Pair(11, 1);
		pairs[1] = new Pair(12, 2);
	}

}
