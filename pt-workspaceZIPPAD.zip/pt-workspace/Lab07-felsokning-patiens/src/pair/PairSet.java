package pair;

public class PairSet {

	/** Skapar en mängd av alla talpar (a,b) sådana att
        0 <= a < rows  och  0 <= b < cols */
	public PairSet(int rows, int cols) {
	}

	/** Undersöker om det finns fler par i mängden. */
	public boolean more() {
		return false;
	}

	/** Hämtar ett slumpmässigt valt talpar ur mängden. Mängden
	 	blir ett element mindre. Om mängden är tom returneras null. */
	public Pair pick() {
		return null;
	}
}
