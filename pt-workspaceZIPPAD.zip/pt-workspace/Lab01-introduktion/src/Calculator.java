import java.util.Scanner;

public class Calculator {
	public static void main(String[] args) {
		System.out.println("Skriv två tal");
		Scanner scan = new Scanner(System.in);
		double nbr1 = scan.nextDouble();
		double nbr2 = scan.nextDouble();
		double sum = nbr1 + nbr2;
		System.out.println("Summan av talen är " + sum);
		double storatal = Math.max(nbr1,nbr2);
		double lillatal = Math.min(nbr1,nbr2);
		// här kan absolutbelopps liknande funktioner användas istället för att
		// ge dem nya värden, ifall man vill göra det enklare
		double skillnaden = storatal - lillatal;
		System.out.println("Skillnaden mellan talen är " + skillnaden);
		System.out.println("Produkten av talen är " + (nbr1*nbr2));
		// utifrån det är kvoten mellan tal 1 och tal 2, annars ifall man vill ha
		// det större talet delat med det lägre ska (storatal/lillatal) användas
		System.out.println("Kvoten mellan talen är " + (nbr1/nbr2));
				
	}
}

