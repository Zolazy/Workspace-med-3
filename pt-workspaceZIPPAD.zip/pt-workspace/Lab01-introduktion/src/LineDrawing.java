import se.lth.cs.pt.window.SimpleWindow;

public class LineDrawing {
	public static void main(String[] args) {
	// SimpleWindow är klassen. w ett objekt som innefattar SimpleWindow specifika
	// egenskaper. Jag refererar till w för att använda koordinater
	// och andra funktioner som SimpleWindow klassen har.
	SimpleWindow w = new SimpleWindow(500, 500, "LineDrawing");
	w.moveTo(0, 0);
	while (true) {
		// Tar man bort waitformouseclick ritar muspekaren linje kontinuerligt
		// längs muspekaren.
		w.waitForMouseClick();
		w.lineTo(w.getMouseX(),w.getMouseY());
		
			// vänta tills användaren klickar på en musknapp
			// rita en linje till den punkt där användaren klickade
		}
	}
}