public class Mole {
	private Graphics g = new Graphics(30, 50, 10);
	
	public static void main(String[] args) {
		Mole m = new Mole();
		m.drawWorld();
		m.dig();
		}
	public void drawWorld(){
		g.rectangle(0,0,30,50,Colors.SOIL);
	}
	
	public void dig() {
		int x = g.getWidth() / 2; // För att börja på mitten
		int y = g.getHeight() / 2;
		while (true) {
			g.block(x, y, Colors.MOLE);
			char key = g.waitForKey();
			if (key == 'w') {
				g.block(x, y, Colors.TUNNEL);
				y = y - 1;
				g.block(x, y, Colors.MOLE);
				}
			else if (key == 'a') {
				g.block(x, y, Colors.TUNNEL);
				x = x - 1;
				g.block(x, y, Colors.MOLE);
			}
			else if (key == 's') {
				g.block(x, y, Colors.TUNNEL);
				y = y + 1;
				g.block(x, y, Colors.MOLE);}
			else if (key == 'd') {
				g.block(x, y, Colors.TUNNEL);
				x = x + 1;
				g.block(x, y, Colors.MOLE);}
		}

	}
}
